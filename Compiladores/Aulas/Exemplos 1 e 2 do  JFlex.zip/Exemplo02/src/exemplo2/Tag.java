package exemplo2;

public class Tag {
    public final static int EOF = 256, PAR_TEXT = 257;
}
