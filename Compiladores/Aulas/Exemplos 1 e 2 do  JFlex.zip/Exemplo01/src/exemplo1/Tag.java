package exemplo1;

public class Tag {
    public final static int EOF = 256, NUMBER = 257, ID = 258, 
            RELOP = 259, IF = 260, THEN = 261, ELSE = 262;
}
